// GUÍA 1
#include<stdio.h>

// EJERCICIO 1
//a
int len(char* s){
    int res = sizeof(s) - 1;
    return res;
}

int main() {
    int b = len(s);
    return b;
}