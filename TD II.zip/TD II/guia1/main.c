#include <stdio.h>
#include <stdlib.h>

int main(){

// 1A -> len("Hola");
// 1B -> copy("Hola!");
}

int len(char* s){
int res = sizeof(&s) - 1;
return res;
return 0;
};

char* copy(char* s){
char res;
res = &s;

return res;
};

// void replaceChar(char* s, char old, char new){}

char* concatenate(char* s1, char* s2){
char* res[0] = s1[0] + s2[0];
return res;

}
