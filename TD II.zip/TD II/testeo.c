int suma(int a, int b) {
    int a = 20;
    int b = 15;
    int s = a + b;
    return s;
}

#Punteros: variables especiales que contienen la dirección de memoria donde se encuentra un dato específico.
#Puedo interactuar con la cosa que apunta. Se declaran usando un * sobre el tipo de variable y se accede a la
#dirección de memoria de un dato usando un &. (&dato)

int main(){
    return 0;
} 